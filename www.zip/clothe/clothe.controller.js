/**
 * Created by Theo on 05/06/2016.
 */
(function() {
  'use strict';

  angular
    .module('cupboard-ng')
    .controller('ClotheController', ClotheController);

  /* @ngInject */
  function ClotheController($scope) {


  }

})();
