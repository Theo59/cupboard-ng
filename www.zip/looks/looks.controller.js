/**
 * Created by Theo on 05/06/2016.
 */
(function() {
  'use strict';

  angular
    .module('cupboard-ng')
    .controller('LooksController', LooksController);

  /* @ngInject */
  function LooksController($scope) {


  }

})();
